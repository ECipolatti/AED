#include <queue>
#include <list>
#include <iterator> // advance
#include <map>

#include "tree.h"
#include "EvaluarArbol.hpp"

using namespace std;
using namespace aed;

/////////////////
// EJERCICIO 1 //
/////////////////
bool tree_equal(tree<int> &T1, tree<int> &T2, tree<int>::iterator it1, tree<int>::iterator it2)
{
	// Si ambos son end, está bien
	if (it1 == T1.end() && it2 == T2.end())
		return true;

	// Sólo uno es end, no son iguales
	if (it1 == T1.end() || it2 == T2.end())
		return false;

	// Ninguno es end, pero tienen distinto valor
	// no son iguales
	if (*it1 != *it2)
		return false;

	// Se debe cumplir para el hijo y para el hermano
	return (tree_equal(T1, T2, it1.lchild(), it2.lchild()) &&
	        tree_equal(T1, T2, ++ it1, ++ it2));
}

bool tree_equal(tree<int> &T1, tree<int> &T2)
{
	return tree_equal(T1, T2, T1.begin(), T2.begin());
}

/////////////////
// EJERCICIO 2 //
/////////////////
bool erasing_equal(tree<int> &T1, tree<int> &T2, tree<int>::iterator it1, tree<int>::iterator it2)
{
	// Si it1 es end, está bien,
	// ya que siempre podemos llegar a un end
	// borrando todo el resto en T2
	if (it1 == T1.end())
		return true;

	// si it2 es end, no hay forma de llegar a T1
	// ya que no podemos insertar nodos
	if (it2 == T2.end())
		return false;

	// Si tienen valores distintos
	// Se avanza it2 hasta que sean iguales.
	while (*it1 != *it2)
	{
		++ it2;

		// Se avanzó todo lo posible it2 y no se encontró *it1?
		// Entonces no es posible
		if (it2 == T2.end())
			return false;
	}

	// Se debe cumplir para el hijo y para el hermano
	return (erasing_equal(T1, T2, it1.lchild(), it2.lchild()) &&
	        erasing_equal(T1, T2, ++ it1, ++ it2));
}

bool erasing_equal(tree<int> &T1, tree<int> &T2)
{
	return erasing_equal(T1, T2, T1.begin(), T2.begin());
}

// Solución alternativa, while sobre los hijos
// Notar que en este caso it2 se debe mandar por referencia
// para que vuelva avanzado en caso de necesitarlo
bool erasing_equal_alt(tree<int> &T1, tree<int> &T2, tree<int>::iterator it1, tree<int>::iterator &it2)
{
	if (it2 == T2.end())
		return false;

	while (*it1 != *it2)
	{
		++ it2;
		if (it2 == T2.end())
			return false;
	}

	tree<int>::iterator c1 = it1.lchild(), c2 = it2.lchild();
	while (c1 != T1.end())
	{
		if (!erasing_equal_alt(T1, T2, c1, c2))
			return false;
		++ c1;
		++ c2;
	}
	return true;
}

bool erasing_equal_alt(tree<int> &T1, tree<int> &T2)
{
	if (T1.empty()) return true;
	tree<int>::iterator it = T2.begin();
	return erasing_equal_alt(T1, T2, T1.begin(), it);
}

/////////////////
// EJERCICIO 3 //
/////////////////
void colapsar_nodo(tree<int> &T, int nodo)
{
	// buscar el nodo
	tree<int>::iterator it = T.find(nodo);

	if (it == T.end())
		return;

	// splice 'atras' del nodo
	tree<int>::iterator c = it.lchild();
	while (c != T.end())
	{
		it = T.splice(it, c);
		++ it;
		c = it.lchild();
	}

	// Finalmente, borrar el nodo buscado
	T.erase(it);
}

/////////////////
// EJERCICIO 4 //
/////////////////
tree<int>::iterator unir_suma(tree<int> &T1, tree<int> &T2, tree<int>::iterator it1, tree<int>::iterator it2)
{
	int suma = *it1;
	while (it1.lchild() != T1.end() && it1.lchild().right() == T1.end())
	{
		// Tiene un solo hijo
		suma += *it1.lchild();
		it1 = it1.lchild();
	}

	it1 = it1.lchild();
	it2 = T2.insert(it2, suma);

	tree<int>::iterator c = it2.lchild();
	while (it1 != T1.end())
	{
		c = unir_suma(T1, T2, it1, c);
		++ c;
		++ it1;
	}

	return it2;
}

void unir_suma(tree<int> &T1, tree<int> &T2)
{
	if (!T1.empty())
		unir_suma(T1, T2, T1.begin(), T2.begin());
}

/////////////////
// EJERCICIO 5 //
/////////////////

// Solución O(n^2)
void suma_nivel_n2(tree<int> &T, list<int> &L, tree<int>::iterator it, int nivel)
{
	list<int>::iterator il = L.begin();
	advance(il, nivel); // de #include <iterator>
	if (il == L.end())
		il = L.insert(il, 0);
	*il += *it;
	tree<int>::iterator c = it.lchild();
	while (c != T.end())
		suma_nivel_n2(T, L, c ++, nivel+1);
}

void suma_nivel_n2(tree<int> &T, list<int> &L)
{
	if (!T.empty())
		suma_nivel_n2(T, L, T.begin(), 0);
}

// Solución O(n log n)
void suma_nivel_nlogn(tree<int> &T, map<int, int> &M, tree<int>::iterator it, int nivel)
{
	M[nivel] += *it;
	tree<int>::iterator c = it.lchild();
	while (c != T.end())
		suma_nivel_nlogn(T, M, c ++, nivel+1);
}

void suma_nivel_nlogn(tree<int> &T, list<int> &L)
{
	if (!T.empty())
	{
		map<int, int> M;
		suma_nivel_nlogn(T, M, T.begin(), 0);
		for (map<int, int>::iterator it = M.begin(); it != M.end(); it ++)
			L.push_back(it->second);
	}
}

// Solución O(n)
void suma_nivel(tree<int> &T, list<int> &L)
{
	if (T.empty()) return;

	// Recorrido a lo ancho con iterador
	// de arbol y de lista (iterativo, no recursivo)
	typedef pair< tree<int>::iterator, list<int>::iterator > ptl;

	queue<ptl> Q;
	L.push_back(0);
	Q.push(make_pair(T.begin(), L.begin()));
	while (!Q.empty())
	{
		ptl p = Q.front();
		Q.pop();
		*p.second += *p.first;

		tree<int>::iterator c = p.first.lchild();
		if (c != T.end())
		{
			list<int>::iterator il = p.second;
			++ il;
			if (il == L.end())
				il = L.insert(il, 0);

			do
			{
				Q.push(make_pair(c ++, il));
			} while (c != T.end());
		}
	}
}

int main(int argc, char *argv[])
{
	EvaluarArbol ev;
	ev.evaluar1(tree_equal);        // Ejercicio 1

	ev.evaluar2(erasing_equal);     // Ejercicio 2
	ev.evaluar2(erasing_equal_alt); // Ejercicio 2

	ev.evaluar3(colapsar_nodo);     // Ejercicio 3

	ev.evaluar4(unir_suma);         // Ejercicio 4

	ev.evaluar5(suma_nivel_n2);     // Ejercicio 5
	ev.evaluar5(suma_nivel_nlogn);  // Ejercicio 5
	ev.evaluar5(suma_nivel);        // Ejercicio 5

	return 0;
}

