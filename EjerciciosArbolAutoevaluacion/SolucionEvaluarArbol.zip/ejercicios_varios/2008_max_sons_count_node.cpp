#include <iostream>
#include "tree.h"
#include "util_tree.h"
using namespace aed;
using namespace std;

void max_sons(tree<int> &T, int &nsonsmax, tree<int>::iterator it, tree<int>::iterator &itmax)
{
	int count = 0;
	tree<int>::iterator c = it.lchild();

	// Cuento los hijos de it
	while (c != T.end())
	{
		++ count;
		++ c;
	}

	// Actualizo el maximo si corresponde
	if (count > nsonsmax)
	{
		nsonsmax = count;
		itmax = it;
	}

	// Recorrido en profundidad
	c = it.lchild();
	while (c != T.end())
		max_sons(T, nsonsmax, c ++, itmax);
}

tree<int>::iterator max_sons(tree<int> &T, int &nsonsmax)
{
	nsonsmax = 0;
	tree<int>::iterator itmax(T.begin());
	if (T.begin() != T.end())
		max_sons(T, nsonsmax, T.begin(), itmax);
	return itmax;
} 

int main(int argc, const char *argv[])
{
	tree<int> T;
	lisp2tree("(3 (4 2 10) (6 7 (8 9 5)) (11 12 13 14 15 16))", T);
	int count;
	tree<int>::iterator it =max_sons(T, count);
	cout << *it << ", " << count << endl;

	return 0;
}
