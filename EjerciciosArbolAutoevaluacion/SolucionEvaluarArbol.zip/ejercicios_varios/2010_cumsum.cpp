#include <iostream>

#include "btree.h"
#include "util_tree.h"

using namespace std;
using namespace aed;

// __FUNC_START__
int cumsum(btree<int> &T, btree<int>::iterator it)
{
	// El nuevo valor de este nodo, es el actual
	// mas el cumsum de sus hijos
	if (it.left() != T.end())
		*it += cumsum(T, it.left());
	if (it.right() != T.end())
		*it += cumsum(T, it.right());

	return *it;
}

void cumsum(btree<int> &T)
{
	if (T.begin() != T.end())
		cumsum(T, T.begin());
}
// __FUNC_END__

int main()
{
	btree<int> BT;
	lisp2btree("(1 5 (2 7 (11 4 2)))", BT);
	cumsum(BT);
	BT.lisp_print();
	cout << endl;

	return 0;
}
