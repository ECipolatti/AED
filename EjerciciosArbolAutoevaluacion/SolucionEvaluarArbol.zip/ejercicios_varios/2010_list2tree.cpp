#include <list>
#include <iostream>
#include "tree.h"
#include "util_tree.h"
using namespace aed;
using namespace std;

// __FUNC_START__
tree<int>::iterator list2tree(tree<int> &T, list<int> &L, list<int>::iterator &lit, tree<int>::iterator it)
{
	it = T.insert(it, *lit++);
	int n = *lit ++;
	tree<int>::iterator c(it.lchild());
	for (int i = 0 ; i < n ; i ++)
	{
		c = list2tree(T, L, lit, c);
		++ c;
	}
	return it;
}

void list2tree(tree<int> &T, list<int> &L)
{
	list<int>::iterator lit(L.begin());
	if (!L.empty())
		list2tree(T, L, lit, T.begin());
}
// __FUNC_END__

int main()
{
	list<int> L;
	string2list("6 5 4 0 8 0 5 2 4 0 4 0 7 0 9 0", L);
	tree<int> T;
	list2tree(T, L);
	T.lisp_print();
	cout << endl;
	return 0;
}
