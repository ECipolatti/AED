#include "btree.h"
#include "util_tree.h"
#include <iostream>
#include <algorithm> // max
using namespace std;
using namespace aed;

// __FUNC_START__
// Devuelve la altura del árbol y por num_nodes la cantidad de nodos
int height_and_count(btree<int> &T, btree<int>::iterator it, int &num_nodes)
{
	if (it == T.end()) return -1;
	++ num_nodes;
	return 1+max(height_and_count(T, it.left(), num_nodes),
	             height_and_count(T, it.right(), num_nodes));
}

bool is_full(btree<int> &T)
{
	int n = 0, h;
	h = height_and_count(T, T.begin(), n);

	// El árbol binario es lleno si tiene 2^(h+1)-1 nodos
	// donde h es la altura
	return ((1 << (h+1)) - 1) == n; // (1 << n) == 2^n
}
// __FUNC_END__

int main(int argc, const char *argv[])
{
	btree<int> T;
	lisp2btree("(1 (2 3 4) (5 6 7))", T); // full
	cout << (is_full(T) ? "lleno" : "no lleno") << endl;

	T.clear();
	lisp2btree("(1 (2 . 4) (5 6 7))", T); // no full
	cout << (is_full(T) ? "lleno" : "no lleno") << endl;

	T.clear();
	lisp2btree("(1 2 3)", T); // full
	cout << (is_full(T) ? "lleno" : "no lleno") << endl;
	return 0;
}
