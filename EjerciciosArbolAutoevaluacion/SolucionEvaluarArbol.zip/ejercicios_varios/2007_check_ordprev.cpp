#include "tree.h"
#include "util_tree.h"
#include "util.h"

#include <iostream>
#include <list>
using namespace aed;
using namespace std;

// __FUNC_START__
// Uso de memoria O(log n), para la recursión
bool check_ordprev(tree<int> &T, list<int> &L, tree<int>::iterator it, list<int>::iterator &il)
{
	if (il == L.end()) return false;
	if (*il != *it)    return false;
	++ il;
	it = it.lchild();
	while (it != T.end())
		if (!check_ordprev(T, L, it ++, il))
			return false;
	return true;
}

bool check_ordprev(tree<int> &T, list<int> &L)
{
	list<int>::iterator il = L.begin();
	if (!T.empty() && !check_ordprev(T, L, T.begin(), il))
		return false;
	return il == L.end();
}

// Solución alternativa con uso de memoria O(n), por la lista auxiliar
bool check_ordprev_alt(tree<int> &T, list<int> &L, tree<int>::iterator it)
{
	L.push_back(*it);
	it = it.lchild();
	while (it != T.end())
		check_ordprev_alt(T, L, it ++);
}

// Simplemente genero una lista con el orden previo
// y verifico si es igual a la que me pasan
bool check_ordprev_alt(tree<int> &T, list<int> &L)
{
	list<int> La;
	if (!T.empty())
		check_ordprev_alt(T, La, T.begin());
	return La == L;
}
// __FUNC_END__

int main(int argc, const char *argv[])
{
	tree<int> T;
	lisp2tree("(3 (4 2 1) 0 (6 7 (8 9 5)))", T);
	list<int> L;
	string2list("3 4 2 1 0 6 7 8 9 5", L);

	cout << (check_ordprev(T, L) ? "Si" : "No") << endl;
	L.clear(); string2list("3 4 2 1 0 6 7 8 9 5 1000",  L);
	cout << (check_ordprev(T, L) ? "Si" : "No") << endl;
	L.clear(); string2list("3 4 2 1 0 6 7000 8 9 5",  L);
	cout << (check_ordprev(T, L) ? "Si" : "No") << endl;

	// Alt
	L.clear(); string2list("3 4 2 1 0 6 7 8 9 5", L);
	cout << (check_ordprev_alt(T, L) ? "Si" : "No") << endl;
	L.clear(); string2list("3 4 2 1 0 6 7 8 9 5 1000",  L);
	cout << (check_ordprev_alt(T, L) ? "Si" : "No") << endl;
	L.clear(); string2list("3 4 2 1 0 6 7000 8 9 5",  L);
	cout << (check_ordprev_alt(T, L) ? "Si" : "No") << endl;

	return 0;
}
